// Supabase configuration will be added after the Supabase project details are connected.
// Do NOT put a service-role key in this file.
// The anon/publishable key is the only browser-side key that belongs here.
const SUPABASE_URL = "";
const SUPABASE_ANON_KEY = "";
