document.getElementById("year").textContent = new Date().getFullYear();

function searchShops(){
  const q=document.getElementById("searchInput").value.trim();
  if(!q){document.getElementById("shops").scrollIntoView({behavior:"smooth"});return;}
  document.getElementById("shops").scrollIntoView({behavior:"smooth"});
}
function filterCategory(category){
  document.getElementById("searchInput").value=category;
  document.getElementById("shops").scrollIntoView({behavior:"smooth"});
}